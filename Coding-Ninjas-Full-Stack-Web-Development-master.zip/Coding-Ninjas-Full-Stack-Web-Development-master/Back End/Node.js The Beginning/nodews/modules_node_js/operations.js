module.exports.add=function(a, b)
{
    return a+b;
}
module.exports.difference=function(a, b)
{
    return Math.max(a, b)-Math.min(a, b);
}
module.exports.multiply=function(a, b)
{
    return a*b;
}