const operations=require('./operations');
console.log(operations.add(1, 5));