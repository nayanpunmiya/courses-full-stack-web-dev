var _=require('lodash');

var a=_.sum([4, 3, 2, 5, 3, 5, 4, 4, 4, 3, 3, 3, 4, 4, 4, 4, 4, 4]);
console.log(a);


