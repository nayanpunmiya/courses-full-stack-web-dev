# BassRize-Online-Music-Player

This online music player is completely based on HTML and CSS.

# Usage Tree
1. index.html
    1. stylesheet_main.css
    2. primary page responsive.css
2. Single Playlist Screen Styles.css
    1. Single Playlist Screen Styles.css
    2. Secondary page responsive.css
3. media

The hierarchy shown above is not the folder structure. The sub-Files are used by the parent file.<br>
`index.html` uses `stylesheet_main.css` for all the basic styling and `primary page responsive.css` for all the meida queries related to responsiveness.<br>
Similarly `Single Playlist Screen.html` uses `Single Playlist Screen Styles.css` for all the basic styling and `Secondary page responsive.css` for all the meida queries related to responsiveness.

# Contribution

Contributions will not be accepted on this repository.
