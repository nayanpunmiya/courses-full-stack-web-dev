document.getElementById('text').addEventListener('drop', function()
{
    console.log('drag started');
});