hosit();
function hosit()
{
    var i=10;
    console.log(i);
}
/* all function and variable declarations are moved up in the current scope */