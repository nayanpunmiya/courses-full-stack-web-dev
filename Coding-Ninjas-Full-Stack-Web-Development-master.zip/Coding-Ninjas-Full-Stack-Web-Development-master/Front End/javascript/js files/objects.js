/* var student={};
console.log(typeof(student)); *///empty object

/* var student = {
    name: "abc",
    roll_number: 43,
    marks: 4
};
console.log(student.marks);
//keys are always strings
 */

 //ways of creating objects
 var obj={};
 //or
 var obj=new Object();
 obj={name:"parikshit", surname:"singh", age:21};
 console.log(obj["name"], obj.surname);