/* var arr=[1, 2, 3, 4];
for(var i=0; i<4; i++)
{
    console.log(arr[i]);
} */
/* var arr= new Array(100);
console.log(arr.length); */
/* var a=[1, 2, 3, 44, 5]
console.log(a.length); */
/* var arr=new Array(1000000000);//max size is 10^9
console.log(arr.length); */

