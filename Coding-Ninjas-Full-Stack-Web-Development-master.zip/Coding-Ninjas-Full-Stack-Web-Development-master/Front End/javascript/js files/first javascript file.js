/* var a=10;
if(a<100)
{
    console.log("positive", a);
} */