function a() {
    console.log("Inside a");

    function b() {
        console.log("Inside b");
    }
}

/* a()b(); *///unexpected identifier error