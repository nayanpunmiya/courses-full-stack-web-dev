function show_alert(msg) 
{
    window.alert(msg);
}
show_alert("hello");