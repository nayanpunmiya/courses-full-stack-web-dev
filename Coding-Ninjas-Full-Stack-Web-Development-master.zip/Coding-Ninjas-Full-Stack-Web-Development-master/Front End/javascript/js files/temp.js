var obj={
    name:"parikshit",
    rollNo:129,
    age:21
};
console.log(obj.__proto__);