console.log(a);
var a = 10;
if (a <= 10) {
    console.log(b);//error
    let b=20;
}

/* var a=10;
if(a<=10)
{
    let b=40;
    //error
}
else
{
    var c=40;
}
console.log(a, b,c ); */
