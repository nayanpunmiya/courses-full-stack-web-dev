"use strict";
var a=20;
a=10;

const c=20;
c=30;//you cannot give a value to a constant variable later and
//neither can you assign a value to a const variable after initialization.
//you have to give them their value, then and there itself.
//hoisting is done in case of consts but it is slightly different.
//we connot refer to the const variables before their declaration and assignment.