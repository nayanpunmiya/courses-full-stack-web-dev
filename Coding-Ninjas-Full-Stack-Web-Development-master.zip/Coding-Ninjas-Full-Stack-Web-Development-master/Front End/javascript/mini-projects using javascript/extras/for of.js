arr=[1, 2, 3, 4, 5, 6, 7, 8, 9];
for(let i of arr)
{
    console.log(i);
}
console.log("..................................");
for(let i=0; i<arr.length; i++)
{
    console.log(arr[i]);
}
console.log("..................................");
for(let i in arr)
{
    console.log(arr[i]);
}
/* 3 ways to iterate */