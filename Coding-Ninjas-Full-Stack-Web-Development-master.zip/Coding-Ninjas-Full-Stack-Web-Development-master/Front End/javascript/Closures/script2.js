(function()
{
    var oolalala=10;
    console.log("file2");
})();